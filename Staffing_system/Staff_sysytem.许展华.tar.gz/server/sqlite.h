#ifndef SQLITE_H
#define SQLITE_H

#include <stdio.h>
#include <sqlite3.h>

sqlite3* sqlite_operation();


#endif
