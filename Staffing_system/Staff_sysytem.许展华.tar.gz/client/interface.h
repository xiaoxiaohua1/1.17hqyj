#ifndef INTERFACE_H
#define INTERFACE_H

#include <stdio.h>
#include "operation.h"

int do_menu(int sfd);
int admin_menu();
int staff_menu();


#endif
